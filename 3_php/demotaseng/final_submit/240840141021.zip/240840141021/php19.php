<?php

$n1 = $_POST["name1"];
$n2 = $_POST["name2"];
$n3 = $_POST["name3"];

echo "The parameters are"."<br>";

echo "<ul>";
echo "<li>".$n1."</li>";
echo "<li>".$n2."</li>";
echo "<li>".$n3."</li>";
echo "</ul>";
?>
