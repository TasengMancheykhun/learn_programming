<html>
    <?php
    for ($x = 1; $x <= 10; $x++) {
        echo "6 * $x = ",6*$x,"<br>";
        }
    ?>
</html>