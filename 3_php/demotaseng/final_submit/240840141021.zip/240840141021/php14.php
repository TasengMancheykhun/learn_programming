<?php
$a = "madam";
$b = strrev($a);

echo "The string \"$a\" in reverse is: \"$b\" <br>";

if ($a == $b){
    echo "The string \"$a\" is a palindrome.";
}



?>
