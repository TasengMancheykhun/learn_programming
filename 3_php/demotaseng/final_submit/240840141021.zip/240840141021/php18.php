<?php
//Assignment 18
// exatract incoming data
//.....welcome.html?uname=taseng

echo "The sum of the number : " . $_GET["uname1"]+$_GET["uname2"]; //taseng




?>